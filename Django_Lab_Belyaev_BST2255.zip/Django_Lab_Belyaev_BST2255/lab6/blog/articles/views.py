# coding: utf-8
from django.shortcuts import render, redirect
from django.http import Http404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from models import Article

def archive(request):
    posts = Article.objects.all().order_by('-created_date')
    return render(request, 'archive.html', {"posts": posts})

def get_article(request, article_id):
    try:
        post = Article.objects.get(id=article_id)
        return render(request, 'article.html', {"post": post})
    except Article.DoesNotExist:
        raise Http404

def create_post(request):
    if not request.user.is_authenticated():
        raise Http404
    
    if request.method == "POST":
        form = {
            'text': request.POST.get("text", ""),
            'title': request.POST.get("title", "")
        }
        
        if Article.objects.filter(title=form['title']).exists():
            form['errors'] = u"Статья с таким названием уже существует"
            return render(request, 'create_post.html', {'form': form})
        
        if form["text"] and form["title"]:
            article = Article.objects.create(
                text=form["text"],
                title=form["title"],
                author=request.user
            )
            return redirect('get_article', article_id=article.id)
        else:
            form['errors'] = u"Не все поля заполнены"
            return render(request, 'create_post.html', {'form': form})
    else:
        return render(request, 'create_post.html', {})

def register_user(request):
    if request.method == "POST":
        username = request.POST.get("username", "")
        email = request.POST.get("email", "")
        password = request.POST.get("password", "")
        password2 = request.POST.get("password2", "")
        
        errors = {}
        
        if not username or not email or not password or not password2:
            errors['empty'] = u"Все поля обязательны для заполнения"
        elif password != password2:
            errors['password'] = u"Пароли не совпадают"
        else:
            try:
                User.objects.get(username=username)
                errors['username'] = u"Пользователь с таким именем уже существует"
            except User.DoesNotExist:
                try:
                    User.objects.get(email=email)
                    errors['email'] = u"Пользователь с таким email уже существует"
                except User.DoesNotExist:
                    user = User.objects.create_user(username, email, password)
                    user.save()
                    return redirect('login')
        
        return render(request, 'register.html', {'errors': errors, 'form': request.POST})
    
    return render(request, 'register.html', {})

def login_user(request):
    if request.method == "POST":
        username = request.POST.get("username", "")
        password = request.POST.get("password", "")
        
        if not username or not password:
            return render(request, 'login.html', {'error': u"Все поля обязательны для заполнения"})
        
        user = authenticate(username=username, password=password)
        
        if user is not None:
            login(request, user)
            return redirect('archive')
        else:
            return render(request, 'login.html', {'error': u"Неверное имя пользователя или пароль"})
    
    return render(request, 'login.html', {})

def logout_user(request):
    logout(request)
    return redirect('archive')