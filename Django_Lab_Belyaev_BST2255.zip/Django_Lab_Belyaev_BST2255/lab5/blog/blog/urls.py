# coding: utf-8
from django.conf import settings
from django.conf.urls import patterns, include, url
from django.contrib import admin
from articles.views import archive, get_article, create_post

admin.autodiscover()

urlpatterns = patterns('',
    url(r'^$', archive, name='archive'),
    url(r'^article/(?P<article_id>\d+)/$', get_article, name='get_article'),
    url(r'^article/new/$', create_post, name='create_post'),
    url(r'^admin/', include(admin.site.urls)),
)

