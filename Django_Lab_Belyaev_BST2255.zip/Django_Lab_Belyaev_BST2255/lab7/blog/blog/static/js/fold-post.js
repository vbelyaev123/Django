// Ждем полной загрузки DOM
document.addEventListener('DOMContentLoaded', function() {
    // Находим все кнопки с классом fold-button
    var foldBtns = document.getElementsByClassName("fold-button");
    
    // Добавляем обработчик для каждой кнопки
    for (var i = 0; i < foldBtns.length; i++) {
        foldBtns[i].addEventListener("click", function(event) {
            // Находим родительский элемент one-post
            var postElement = event.target.parentElement;
            
            // Проверяем, есть ли у поста класс folded
            if (postElement.className.indexOf("folded") !== -1) {
                // Если есть - разворачиваем
                postElement.className = "one-post";
                event.target.innerHTML = "свернуть";
            } else {
                // Если нет - сворачиваем
                postElement.className = "one-post folded";
                event.target.innerHTML = "развернуть";
            }
        });
    }
});