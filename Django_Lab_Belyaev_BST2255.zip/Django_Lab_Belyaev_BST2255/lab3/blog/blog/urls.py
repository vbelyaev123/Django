# coding: utf-8
from django.conf import settings
from django.conf.urls import patterns, include, url
from django.contrib import admin
from articles.views import archive

admin.autodiscover()

urlpatterns = patterns('',
    url(r'^$', archive, name='archive'),
    url(r'^admin/', include(admin.site.urls)),
)
