$(document).ready(function() {
    // Переменные для параллакса
    var scrolled = 0;
    
    // Элементы для анимации
    var $parallaxElements = $('.icons-for-parallax img');
    var $logo = $('.logo');
    
    // Начальные позиции
    var initialTop = [];
    $parallaxElements.each(function(i) {
        initialTop[i] = parseInt($(this).css('top')) || 0;
    });
    
    // Функция анимации параллакса
    function animateParallax() {
        scrolled = $(window).scrollTop();
        
        // Анимация для иконок с разной скоростью
        $parallaxElements.each(function(index) {
            var speeds = [0.15, 0.12, 0.09];
            var speed = speeds[index] || 0.1;
            var yPosition = initialTop[index] + (scrolled * speed);
            $(this).css({ top: yPosition });
        });
        
        // Анимация для логотипа (медленное движение)
        var logoYPosition = scrolled * 0.05;
        $logo.css({ 
            transform: 'translateY(' + logoYPosition + 'px)'
        });
    }
    
    // Оптимизированный обработчик прокрутки
    var ticking = false;
    $(window).scroll(function() {
        if (!ticking) {
            requestAnimationFrame(function() {
                animateParallax();
                ticking = false;
            });
            ticking = true;
        }
    });
    
    // Запускаем при загрузке
    animateParallax();
});