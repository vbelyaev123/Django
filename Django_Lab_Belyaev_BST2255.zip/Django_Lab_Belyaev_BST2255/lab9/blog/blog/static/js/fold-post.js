$(document).ready(function() {
    // Находим все кнопки с классом fold-button
    $('.fold-button').click(function() {
        // Находим родительский элемент one-post
        var postElement = $(this).closest('.one-post');
        
        // Переключаем класс folded
        postElement.toggleClass('folded');
        
        // Меняем текст кнопки
        if (postElement.hasClass('folded')) {
            $(this).text('развернуть');
        } else {
            $(this).text('свернуть');
        }
    });
});