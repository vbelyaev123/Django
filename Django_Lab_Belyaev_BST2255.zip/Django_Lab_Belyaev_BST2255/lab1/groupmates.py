# coding:utf-8
groupmates = [
    {
        "name": u"Виктор",
        "group": u"БСТ2255",
        "age": 19,
        "marks": [4, 3, 5, 5, 4]
    },
    {
        "name": u"Ниджат",
        "group": u"БСТ2255",
        "age": 18,
        "marks": [3, 2, 3, 4, 3]
    },
    {
        "name": u"Дмитрий",
        "group": u"БСТ2256",
        "age": 19,
        "marks": [3, 5, 4, 3, 5]
    },
    {
        "name": u"Павел",
        "group": u"БСТ2257",
        "age": 18,
        "marks": [5, 5, 5, 4, 5]
    },
    {
        "name": u"Ростислав",
        "group": u"БСТ2257",
        "age": 18,
        "marks": [5, 5, 5, 4, 5]
    }
]

def print_students(students):
    print u"Имя студента".ljust(15), \
          u"Группа".ljust(8), \
          u"Возраст".ljust(8), \
          u"Оценки".ljust(20)
    for student in students:
        print student["name"].ljust(15), \
              student["group"].ljust(8), \
              str(student["age"]).ljust(8), \
              str(student["marks"]).ljust(20)
    print "\n"

# Функция для фильтрации студентов по среднему баллу
def filter_students_by_average(students, min_average):
    filtered_students = []
    for student in students:
        average = sum(student["marks"]) / float(len(student["marks"]))
        if average >= min_average:
            filtered_students.append(student)
    return filtered_students

print_students(groupmates)

# Пример использования фильтрации
min_avg = 4.0
print u"Студенты со средним баллом >= {}:".format(min_avg)
filtered = filter_students_by_average(groupmates, min_avg)
print_students(filtered)
