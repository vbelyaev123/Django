// Ждем полной загрузки DOM
$(document).ready(function() {
    // Находим все кнопки с классом fold-button
    $('.fold-button').click(function(event) {
        // Находим родительский элемент one-post
        var postElement = $(this).closest('.one-post');
        
        // Проверяем, есть ли у поста класс folded
        if (postElement.hasClass('folded')) {
            // Если есть - разворачиваем
            postElement.removeClass('folded');
            $(this).text('свернуть');
        } else {
            // Если нет - сворачиваем
            postElement.addClass('folded');
            $(this).text('развернуть');
        }
    });
});