$(document).ready(function() {
    // Эффект подсветки при наведении на пост
    $('.one-post').hover(function(event) {
        // Находим shadow элемент внутри текущего поста и изменяем прозрачность
        $(event.currentTarget).find('.one-post-shadow').animate({
            opacity: '0.1'
        }, 300);
    }, function(event) {
        // Возвращаем прозрачность обратно
        $(event.currentTarget).find('.one-post-shadow').animate({
            opacity: '0'
        }, 300);
    });
    
    // Эффект увеличения логотипа при наведении
    $('.logo').hover(function() {
        // Увеличиваем логотип при наведении
        $(this).animate({
            width: '338px',  // увеличиваем на 20px (было 318px)
            height: 'auto'   // высота меняется пропорционально
        }, 300);
    }, function() {
        // Возвращаем исходный размер
        $(this).animate({
            width: '318px',
            height: 'auto'
        }, 300);
    });
});